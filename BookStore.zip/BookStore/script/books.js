const cartButton = document.querySelector('.cart-button');
const cart = document.querySelector('.cart');
const cartList = document.querySelector('.cart-list');
const bookList = document.querySelector('.book-list');

let cartItems = [];

function updateCart() {
	cartList.innerHTML = '';
	if (cartItems.length === 0) {
		cartList.innerHTML = '<li>Empty</li>';
	} else {
		cartItems.forEach(function(item) {
			const li = document.createElement('li');
			const title = document.createElement('span');
			title.textContent = item.title;
			title.classList.add('cart-book-title');
			const name = document.createElement('span');
			name.textContent = item.name;
			name.classList.add('cart-book-name');
			const price = document.createElement('span');
			price.textContent = ' ₹' + item.price;
			price.classList.add('cart-book-price');
			li.appendChild(title);
			li.appendChild(name);
			li.appendChild(price);
			cartList.appendChild(li);
		});
		// Create "Buy Now" button
		const buyNowButton = document.createElement('button');
		buyNowButton.textContent = 'Buy Now';
		buyNowButton.classList.add('buy-now-button');
		cartList.appendChild(buyNowButton);
		// Attach click event listener to "Buy Now" button
		buyNowButton.addEventListener('click', function() {
			alert('Thank you for your purchase!');
			cartItems = [];
			updateCart();
		});
	}
	cartButton.textContent = 'Cart (' + cartItems.length + ')';
}

function addToCart(name, title, price) {
	cartItems.push({name, title, price});
	updateCart();
}

cartButton.addEventListener('click', function() {
	cart.classList.toggle('show-cart');
});

bookList.addEventListener('click', function(event) {
	if (event.target.classList.contains('add-to-cart')) {
		const name = event.target.previousElementSibling.previousElementSibling.previousElementSibling.textContent;
		const title = event.target.previousElementSibling.previousElementSibling.textContent;
		const price = parseFloat(event.target.previousElementSibling.textContent.replace('₹', ''));
		addToCart(name, title, price);
	}
});